# Wurdle

## Wurdle is a socket-based online multiplayer.

![Wurdle](preview.png)

## Setup
`./run_server`