package uta.group23.wurdle.grid;

public enum Direction {
    Horizontal, Vertical, DiagonalUp, DiagonalDown
}