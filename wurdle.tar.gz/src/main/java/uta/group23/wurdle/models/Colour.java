package uta.group23.wurdle.models;

public enum Colour {
    Red,
    Green,
    Blue,
    Yellow,
    Purple,
    Cyan;

    public void changeColour() {

    }
}
