package uta.group23.wurdle.models;

public enum ChatScope {
    Global,
    Local;

    public static void changeScope() {

    }
}
