package uta.group23.wurdle.socket;

import uta.group23.wurdle.socket.Lobby;

public enum Mode {
    Timer,
    Point;

    public static void changeMode(Lobby lobby) {

    }

}