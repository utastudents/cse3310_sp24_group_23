package uta.group23.wurdle.socket;

import uta.group23.wurdle.socket.Lobby;

public enum Status {
    WAITING,
    IN_PROGRESS,
    FINISHED;

    public static void changeStatus(Lobby lobby) {

    }
}